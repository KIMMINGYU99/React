import Page from "../organism/Page";

function App() {
  return <Page />;
}

export default App;
